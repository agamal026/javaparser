# Proposed pull request

**Unsubmitted draft:** the validation below is complete for the recorded Linux
run; publishing access remains unavailable.

## Title

Preserve spacing before the type when removing the last import

## Body

Fixes [#4074](https://github.com/javaparser/javaparser/issues/4074).

Removing the last of several imports with `LexicalPreservingPrinter` can consume
an existing blank line before the class. The syntax-model difference can retain
the newline before the removed import and delete a trailing newline instead.

This change corrects that alignment in
`LexicalDifferenceCalculator.calculateListRemovalDifference`. For a final import
with a predecessor, it recognizes the exact removed child and surrounding
kept/removed newline pattern, then makes the preceding separator the deleted
newline. The existing spacing before the type is preserved, including when the
source has no blank line. The change is limited to that import-removal pattern;
`Difference.java` is unchanged.

The new regression class has 20 LF/CRLF cases covering import position, original
blank-line count, spaces/tabs on a blank line, successive removals, a class
documentation comment, and an indented import.

### Validation

On base `dc6bc07155cb0d0d7a8a427b76411848eb862136`, the initial single regression
failed and the expanded 202-test selection had six failures. The revised
208-test selection passed with four skips; that run contained 18 new cases.
The final formatted 20-case version passed in the full reactor on Linux with
Java 17.0.20.1. The executed command used `--log-file` to retain Maven output;
only that destination is represented by `$REVIEW_PACKET` below:

```sh
./mvnw --errors --show-version -B -ntp \
  --log-file "$REVIEW_PACKET/final-reactor-slow/maven.log" \
  clean test --activate-profiles AlsoSlowTests
```

Result: **5,831 tests, zero failures, zero errors, 35 skips; all nine reactor
modules successful**, including all 20 new regression cases. Both explicit
generator modules, the final root install, Spotless application, and
`checkstyle:check spotless:check` also succeeded.

Surefire emitted a corrupted-channel warning about direct native-stream output
in the symbol-solver JVM. The retained dumpstream contains only informational
G1 GC output; no test failure or error was reported.
Earlier setup failures and two incomplete post-metamodel console captures remain
documented. No upstream hosted platform/JDK matrix has run for this candidate.

### Prior work and AI assistance

Thanks to [MysterAitch's earlier work in #2704](https://github.com/javaparser/javaparser/pull/2704)
on newline preservation and horizontal whitespace. A small adaptation of the
horizontal-whitespace approach was tested on the current base but introduced
an unwanted blank line in the zero-blank-line LF/CRLF cases. This patch instead
corrects the import separator's structural alignment.

AI assistance was used for investigation, code and regression development,
validation triage, and this description. A separate automated agent reviewed the
candidate source; automated review is identified as such.
