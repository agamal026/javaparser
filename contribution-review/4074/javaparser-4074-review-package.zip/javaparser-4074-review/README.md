# JavaParser #4074 — validated contribution review packet

**Status:** the two-file candidate passed the explicit generator stages,
formatting checks, and the full nine-module reactor with `AlsoSlowTests` on
Linux and Java 17.0.20.1: **5,831 tests, zero failures/errors, 35 skips**.
Publication remains blocked. No upstream fork, PR, issue comment, or payment
has been established for this work.

This packet concerns [JavaParser #4074](https://github.com/javaparser/javaparser/issues/4074)
on the pinned upstream base
[`dc6bc07155cb0d0d7a8a427b76411848eb862136`](https://github.com/javaparser/javaparser/commit/dc6bc07155cb0d0d7a8a427b76411848eb862136).
It includes a [proposed PR draft](PROPOSED_PR.md) and
[automated review record](AUTOMATED_REVIEW.md).

## Problem and candidate behavior

Removing the last of several imports through the lexical-preserving printer
can remove an existing blank line before the class. The original single-case
regression starts with:

```java
import a;
import b;

class X{}
```

After `cu.getImports().remove(1)`, the expected output retains the blank line
between `import a;` and `class X{}`. The pinned baseline instead prints the two
remaining lines consecutively. The recorded assertion failure establishes this
behavior independently of the earlier network setup failures.

The production change is confined to
`javaparser-core/src/main/java/com/github/javaparser/printer/lexicalpreservation/LexicalDifferenceCalculator.java`,
in `calculateListRemovalDifference`. It corrects an ambiguous newline alignment
in the calculated difference. The correction applies only when:

- The observed property is `IMPORTS`.
- The removed import is last and has a predecessor.
- The removed child is the exact node at the removal index.
- Its surrounding difference is a kept newline, the removed child, a kept
  newline, and a removed newline.

The swap makes the separator **before** the removed import the deleted newline,
preserving the original separator before the type. It does not impose a fixed
number of blank lines. Other difference patterns retain the existing result.
`Difference.java` was restored to its baseline contents.

The new `Issue4074Test.java` contains **20 parameterized cases** covering LF and
CRLF input, removal from the first/middle/last import positions, zero/one/two
blank lines before a class, whitespace inside a blank line, successive removals,
a class documentation comment, and an indented final import. CRLF inputs were
tested on Linux; this is not a Windows execution claim.

## Earlier work and rejected approach

[MysterAitch's PR #2704](https://github.com/javaparser/javaparser/pull/2704),
“WIP -- Generators and Lexical Preserving Printer,” contains earlier work on
newline preservation and horizontal-whitespace handling. That work informed
the initial investigation and is credited here.

A small horizontal-whitespace-only adaptation in `Difference.java` was tested
on the current pinned base and rejected. It fixed the ordinary blank-line
example but inserted an unwanted blank line when the original separator had
none, failing both LF and CRLF cases. The retained
`rejected-horizontal-cleanup.patch` records that discarded local candidate.
This is a result for that adaptation on the pinned base, not a test verdict on
the complete historical PR. The final candidate corrects the structural
alignment in `LexicalDifferenceCalculator` instead.

## Exact source and patch identities

The final style/full-reactor receipts and `patch-verification.json` identify:

| File | SHA-256 |
| --- | --- |
| `LexicalDifferenceCalculator.java` in the production directory above | `2f2332d18e4aa3f3a3ffd05b728c316fa076acda041eeec4431e25f6688a5ffd` |
| Final formatted `javaparser-core-testing/src/test/java/com/github/javaparser/printer/lexicalpreservation/Issue4074Test.java` | `728756173731ad002590c82f706a8664bfff97456f0e4a87c96f6454a0dbe996` |
| Baseline-restored `Difference.java` beside the production file | `6889d919ff394c46f062aaf762a43ae8e2f0189b34c2eb1ac732cc3ecca2603e` |

[The final patch](javaparser-4074.patch) is **7,710 bytes**, SHA-256
`0cb1bfaaf7ea00dc7bceea187373c0b6843c4f6f350ad93bbc743468985f60b9`.
The [patch verification](patch-verification.json), recorded at
`2026-10-18T00:00:32.038293Z`, used isolated Git indexes to check and apply it
against the pinned base. The recovered tree exactly matched candidate tree
`be582247d3fdd80bf6e72c7dca6a52922cbd19a7`: two changed paths,
142 insertions and one deletion. This is patch recovery evidence, not a
published commit or upstream submission.

## Executed commands and observed results

The recorded environment used Linux, Eclipse Adoptium Java **17.0.20.1**, and
the Maven wrapper's **Maven 3.10.0**. The commands below were run at the repository
root. Cloud-specific dependency-cache, proxy, and trust-store settings were
execution setup; their machine paths and connection details are omitted here.

The original single-case regression, after resolving setup failures, used:

```sh
./mvnw -U -B -ntp --show-version \
  -pl javaparser-core-testing -am test \
  -Dtest=Issue4074Test \
  -Dsurefire.failIfNoSpecifiedTests=false
```

The expanded baseline, rejected candidate, and revised focused run used the
same selection command, with the distinct test/source versions noted below:

```sh
./mvnw -B -ntp -pl javaparser-core-testing -am test \
  -Dtest=Issue4074Test,LexicalPreservingPrinterTest,DifferenceApplyRemovedRulesCompleteTest,DifferenceApplyLeftoverRulesTest,MethodDeclarationTransformationsTest,CompilationUnitTransformationsTest \
  -Dsurefire.failIfNoSpecifiedTests=false
```

The earlier core-module test run used:

```sh
./mvnw -B -ntp --errors -pl javaparser-core-testing -am test
```

| Evidence record | Finished at, UTC on October 17, 2026 | Tests | Failures | Errors | Skips | Exit |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| `baseline-regression-runtime-ca` — original one-case regression | 23:31:43.236789 | 1 | 1 | 0 | 0 | 1 |
| `baseline-expanded` — baseline production, 12 new cases plus selected existing tests | 23:32:54.328820 | 202 | 6 | 0 | 4 | 1 |
| `candidate-horizontal-cleanup` — rejected adaptation, same 12 new cases | 23:33:40.538316 | 202 | 2 | 0 | 4 | 1 |
| `candidate-import-separator` — revised production, 18 new cases plus selected existing tests | 23:39:12.315891 | 208 | 0 | 0 | 4 | 0 |
| `core-suite` — core testing module and required reactor dependencies, 20 cases before final formatting | 23:40:44.744242 | 2,924 | 0 | 0 | 8 | 0 |

The focused 208-test result used an earlier **18-case** version of the regression
file, SHA-256 `41243bec344fac2829c0c3b7070332b1be3d74378cd1f9aff0ab25c74da201b5`.
The earlier core run used the **20-case pre-format** test file, SHA-256
`8380d49e42f93d8afe8df37f34fb85d4664913910d3403d19102779e5c44a600`.
It is distinct from the final formatted file identified above. The original
single-case file had SHA-256
`744bfe1718ec2d1ad1c8247efc4205f93af75cc2e16c1fd991ff3248e8dde90e`;
the 12-case baseline and rejected-candidate file had SHA-256
`e3dfa6cd1a0f8ffd0432d6f3a6bc6d889e418742a9a64d4f95f0f0731a504f42`.
Only the 12-case historical version is separately preserved as
`baseline-expanded-test.java`; the one-case and 18-case versions are identified
by their receipts, not claimed as separately packaged source snapshots.

Each record has a preserved `receipt.json` and `build.log`. The full core
`build.log` is authoritative for the aggregate: its 296 per-group summaries sum
to **2,924 tests**, matching Maven's final aggregate;
its SHA-256 is
`ce0fb1d2d00132f8449611aeb483a57bc1e2c62de25ed7894d1ef30652bd9a4c`.
The copied per-group text-report collection is incomplete for nested and
display-named groups: its 246 summaries total 2,673 tests, a difference of
251 tests. The 2,924 count is supported by the full log, not by claiming that
copied collection is exhaustive. The retained `Issue4074Test` report
independently records all 20 pre-format cases passing, with no failures, errors,
or skips. This collection limitation concerns the earlier `core-suite` record.

## Generator, style, and final full-reactor validation

The stages prescribed by the pinned
[contribution guide](https://github.com/javaparser/javaparser/blob/dc6bc07155cb0d0d7a8a427b76411848eb862136/CONTRIBUTING.md)
were executed individually after the initial script failure. Both explicit
generator module invocations, the final root install, Spotless application,
and Checkstyle/Spotless verification returned exit 0 with terminal Maven success.
Generator/install receipts retain their intermediate generated-source hashes;
the final style and full-reactor receipts use the final hashes above.

These are the executed Maven arguments. Only absolute log destinations are
represented by the portable `$REVIEW_PACKET` placeholder; the receipts retain
the original command arrays. Module commands ran in the indicated directories.

```sh
# In javaparser-core-metamodel-generator:
../mvnw --errors --show-version -B -ntp clean package -P run-generators -DskipTests

# In javaparser-core-generators:
../mvnw --errors --show-version -B -ntp \
  --log-file "$REVIEW_PACKET/codegen-core-module/maven.log" \
  clean package -P run-generators -DskipTests

# At the repository root:
./mvnw --errors --show-version -B -ntp \
  --log-file "$REVIEW_PACKET/codegen-post-core-install/maven.log" \
  clean install -DskipTests
./mvnw -B -ntp --log-file "$REVIEW_PACKET/spotless-apply/maven.log" spotless:apply
./mvnw -B -ntp --log-file "$REVIEW_PACKET/style-verification/maven.log" \
  checkstyle:check spotless:check
./mvnw --errors --show-version -B -ntp \
  --log-file "$REVIEW_PACKET/final-reactor-slow/maven.log" \
  clean test --activate-profiles AlsoSlowTests
```

| Record | Finished at, UTC | Outcome |
| --- | --- | --- |
| `codegen-metamodel-module` | 2026-10-17 23:52:57.136453 | Explicit metamodel generation succeeded; `build.log` is authoritative. |
| `codegen-core-module` | 2026-10-17 23:56:22.221339 | Explicit core generation succeeded. |
| `codegen-post-core-install` | 2026-10-17 23:57:37.011171 | All nine reactor modules succeeded; tests skipped. |
| `spotless-apply` | 2026-10-17 23:58:28.041213 | Formatting succeeded across all nine modules. |
| `style-verification` | 2026-10-17 23:59:18.574467 | All nine modules succeeded; zero Checkstyle violations and no Spotless changes required. |
| `final-reactor-slow` | 2026-10-18 00:02:22.893877 | All nine reactor modules succeeded with `AlsoSlowTests`. |

For commands using `--log-file`, **`maven.log` is authoritative**. Their normal
`build.log` files are intentionally empty, and the receipt's `log_sha256` hashes
that empty console file rather than Maven's redirected output.

The final full-reactor run began at `2026-10-17T23:59:50.452912Z`. Its module
aggregates are:

| Test module | Tests | Failures | Errors | Skips |
| --- | ---: | ---: | ---: | ---: |
| Core testing | 2,924 | 0 | 0 | 8 |
| Core BDD testing | 625 | 0 | 0 | 0 |
| Core generators | 3 | 0 | 0 | 0 |
| Core serialization | 11 | 0 | 0 | 0 |
| Symbol-solver testing | 2,268 | 0 | 0 | 27 |
| **Total** | **5,831** | **0** | **0** | **35** |

All **20 final formatted regression cases** passed. The authoritative
`final-reactor-slow/maven.log` has SHA-256
`b3691d527a7539384101b29cdacc653dd270712556fdb5a4cb6b04290773c998`.
The [final summary](final-reactor-slow/summary.json) records the same source,
command, aggregates, and log digest. Independent automated review also reconciled
all 617 per-group summaries to those totals.

Surefire reported a corrupted-channel warning concerning direct native-stream
output in the forked symbol-solver JVM. The retained dumpstream contains
**324 informational G1 GC output records**, with no exception, out-of-memory,
fatal, or unclassified payload. Its SHA-256 is
`1370b90b080ee4b8a563098ef5d51bdb92f802aa82a940f028e7236e8ea5710a`;
`summary.json` identifies its retained location. The warning is preserved and
classified as GC logging; Maven reported zero test failures/errors and a
successful reactor. These results cover Linux/Java 17.0.20.1, not the upstream
hosted multi-platform/JDK matrix.

## Preserved setup failures and logging limitations

The initial `baseline-regression` command omitted `-U` and stopped before tests
on Maven Central DNS resolution. The subsequent `baseline-regression-proxy`
attempt used the single-case command shown above but stopped on TLS trust-chain
validation. Both returned exit 1. After the runtime trust configuration was
corrected, the same regression reached its actual assertion failure. These
earlier setup attempts remain failures; they are not test results.

The first required generator command was:

```sh
./run_core_metamodel_generator.sh
```

The `codegen-metamodel` receipt records exit **1** at
`2026-10-17T23:42:30.507337Z`. Its captured log ends during the initial prerequisite
build without a conclusive failure diagnostic. The cause of that attempt remains
unclassified; it does not establish successful generation by that script.

A separate prerequisite investigation used:

```sh
./mvnw -B -ntp --errors --show-version clean install -DskipTests
```

The `codegen-prerequisite-install` receipt records exit **1** at
`2026-10-17T23:44:47.261084Z`, with a clean-plugin error deleting generated BDD
coverage output. This later diagnostic does not prove the cause of the earlier
unclassified script exit. A command using `-DskipTests` cannot establish a passing
test suite.

The same prerequisite command later completed successfully in
`codegen-prerequisite-clean-recovery` at `2026-10-17T23:47:37.546816Z`: exit **0**,
all **nine reactor modules successful**, with tests skipped. Its source hashes
match the successful core-test receipt. The recovery log has SHA-256
`fa0793c88fa89a548f35ab276a721de2420aa24716e836edd5893b7902cf13e4`.
This establishes the prerequisite build, not passing tests.

Two subsequent post-metamodel root-install attempts returned exit 0 but their
console captures lacked terminal Maven build summaries:
`codegen-post-metamodel-install` and
`codegen-post-metamodel-install-recheck`. Their completeness remains unverified;
the logging limitation is unresolved. The later explicit final root install
provides the all-nine-module success needed for that build gate. It does not
retroactively turn the earlier incomplete captures into verified successes.

The `newline-diagnostic` trace and helper concern the **rejected horizontal-only
candidate**, including its unwanted blank line for the zero-blank-line input.
They are not final-candidate test evidence. The helper alone does not emit the
internal trace without instrumentation; compiled classes and the copied full
instrumented `Difference.java` are excluded from the compact review packet.

## Publication and continuation

Publication is blocked at this checkpoint: the available cloud GitHub
connector exposes no fork-creation operation, the prior browser publishing bridge
is unavailable, and the inspected cloud GitHub browser session is signed out.
No fork, upstream PR, issue comment, or hosted CI run is claimed. The contribution
guide asks contributors to announce work on the issue; that comment remains
unsent under the same access limitation.

Keep the complete unpublished patch/source packet **outside the open-source
hub**. The hub's `AGENTS.md` explicitly excludes unpublished third-party patch
content; it may receive only selected public progress summaries. Publish the
full packet through an authorized contributor fork when that capability is
available. Verify the actual fork, source commit, and upstream PR before
changing the submission count. The work has no established issue-specific
bounty, paid assignment, award, or payment.

AI assistance was material to the investigation, candidate implementation,
regression design, execution triage, and documentation. A separate automated
agent reviewed the candidate source. Automated review is recorded separately
from personal review and maintainer acceptance.
