# Reproduce the JavaParser #4074 candidate

The saved validation is complete for the recorded Linux / Java 17 environment.
Reuse those results when resuming unchanged source. Run these commands when
independent reproduction, changed source, or another required environment makes
another execution useful.

## Recover the exact candidate

Start with the upstream repository and the commit recorded in
`patch-verification.json`. Apply `javaparser-4074.patch` from this package to
that baseline. The two changed paths, SHA-256 file digests, patch digest, and
complete candidate Git tree are recorded in that verification file.

```sh
git clone https://github.com/javaparser/javaparser.git javaparser-4074
cd javaparser-4074
git checkout --detach dc6bc07155cb0d0d7a8a427b76411848eb862136
git apply --check ../javaparser-4074-review/javaparser-4074.patch
git apply ../javaparser-4074-review/javaparser-4074.patch
git diff --check
```

The example assumes this archive was extracted beside the clone, into its
`javaparser-4074-review` directory. Adjust only that package location as needed.
`patch-verification.json` records a successful isolated-index application that
reconstructed tree `be582247d3fdd80bf6e72c7dca6a52922cbd19a7` exactly; no
candidate commit or upstream submission is implied by this tree identity.

## Required generation and style sequence

Use a supported JDK and the repository's Maven wrapper. The recorded execution
used Temurin Java 17.0.20.1 and wrapper-selected Maven 3.10.0. Inspect the exit
status and terminal Maven result at **each** stage; the repository's generator
shell wrappers do not check every intermediate generator command.

```sh
./mvnw --errors --show-version -B clean install -DskipTests
(cd javaparser-core-metamodel-generator && ../mvnw --errors --show-version -B clean package -P run-generators -DskipTests)
./mvnw --errors --show-version -B clean install -DskipTests
(cd javaparser-core-generators && ../mvnw --errors --show-version -B clean package -P run-generators -DskipTests)
./mvnw --errors --show-version -B clean install -DskipTests
./mvnw -B spotless:apply
./mvnw -B checkstyle:check spotless:check
```

Generation temporarily rewrote many core files. After Spotless, inspection
confirmed that only the intended production file and new regression file
remained changed. The production bytes were unchanged by final formatting;
the regression file received formatting changes and was tested again in the
final reactor run.

The recorded cloud had a Maven clean failure deleting generated coverage HTML.
Only generated module `target` directories were retained outside the checkout
before subsequent clean builds; source files were not moved or reset. The
`build-output-recovery*.json` records preserve those actions. This is a
diagnosed environment workaround, not a step needed by every installation.

## Final test scope

```sh
./mvnw --errors --show-version -B -ntp --log-file maven-final.log clean test --activate-profiles AlsoSlowTests
```

The recorded final run passed all nine reactor modules, reporting 5,831 tests,
zero failures, zero errors, and 35 skips. The new regression class contributed
20 passing LF/CRLF cases. This is one Linux / Java 17 execution, not an upstream
hosted operating-system and JDK matrix.

Maven's `--log-file` was used after two earlier console captures ended without
terminal build summaries despite exit zero. For these later commands,
`build.log` is intentionally empty; the substantive evidence is `maven.log`.
The manifest hashes both separately. See `final-reactor-slow/summary.json` for
the final aggregates, source digests, and complete Maven-log digest.

## Baseline and rejected candidate

For the expanded failing baseline, use a separate clean worktree at the pinned
base and copy `baseline-expanded-test.java` to the new test's recorded path.
Use the exact focused command in `baseline-expanded/receipt.json`; it reported
202 tests with six failures, zero errors, and four skips. Applying only the
retained `rejected-horizontal-cleanup.patch` to that baseline produced the two
zero-blank-line failures recorded in `candidate-horizontal-cleanup`.

The 12-case historical test snapshot is retained. The original one-case and
intermediate 18-case files are identified by their receipts but are not present
as separate source snapshots. The final 20-case source is fully included in
the final patch.

`run_check.py` is the original environment-specific recording script. Its
paths are historical provenance; the portable commands above do not require
that particular cloud directory or its dependency configuration. No credentials,
Maven connection settings, dependency caches, or generated binaries are bundled.

